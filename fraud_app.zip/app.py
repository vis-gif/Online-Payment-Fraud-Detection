
from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
import pandas as pd

app = Flask(__name__)

# Load your trained model
model = joblib.load("fraud_model.pkl")

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        form_data = request.form

        input_dict = {
            'Transaction_Type': form_data['Transaction_Type'],
            'Payment_Gateway': form_data['Payment_Gateway'],
            'Transaction_City': form_data['Transaction_City'],
            'Transaction_State': form_data['Transaction_State'],
            'Transaction_Status': form_data['Transaction_Status'],
            'Device_OS': form_data['Device_OS'],
            'Merchant_Category': form_data['Merchant_Category'],
            'Transaction_Channel': form_data['Transaction_Channel'],
            'Transaction_Frequency': int(form_data['Transaction_Frequency']),
            'Transaction_Amount_Deviation': float(form_data['Transaction_Amount_Deviation']),
            'Days_Since_Last_Transaction': int(form_data['Days_Since_Last_Transaction']),
            'amount': float(form_data['amount']),
            'Hour': int(form_data['Hour'])
        }

        input_df = pd.DataFrame([input_dict])
        prediction = model.predict(input_df)[0]

        result = "Fraudulent" if prediction == 1 else "Not Fraudulent"
        return render_template("index.html", prediction=result)

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
